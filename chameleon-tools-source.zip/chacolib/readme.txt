
TODO:

- make flash writing erase and write blocks in the same loop

- port to libusbX (https://sourceforge.net/apps/mediawiki/libusbx/index.php?title=Main_Page)

