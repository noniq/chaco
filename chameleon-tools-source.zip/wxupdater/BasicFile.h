

#ifndef _BASIC_FILE_H_
#define _BASIC_FILE_H_

int loadFile(unsigned char ** data, int * size, char * filename);
int FileLength(char * filename);

#endif
