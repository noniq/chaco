#define __COREVERSION__ "beta9d"
