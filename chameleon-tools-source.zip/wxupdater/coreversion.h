#define __COREVERSION__ "beta9o"
