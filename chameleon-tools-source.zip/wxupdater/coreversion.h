#define __COREVERSION__ "beta9e"
