#define __COREVERSION__ "beta9h"
